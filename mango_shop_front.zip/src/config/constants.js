export const API_URL = process.env.NODE_ENV === "production" ? "https://port-0-mango-shop-server2-p8xrq2mlfg43w7v.sel3.cloudtype.app/" : "http://localhost:8080";
